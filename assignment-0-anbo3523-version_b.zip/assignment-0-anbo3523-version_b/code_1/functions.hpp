#ifndef READFILE_H__
#define READFILE_H__

#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// TODO add detailed explanation on what the function should do
int fooA();

#endif // READFILE_H__